/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cv01;

import java.io.IOException;
import java.util.Random;

/**
 *
 * @author zeman12
 */
public class Doklad {
    double zaklad; //pro výpocet dane
    double dph; //spoctena hodnota dane
    double celkem; //celkova hodnota (zaklad+dph)
    double sazba = 0.21; //velikost dane
    int nazevDokladu;

    public Doklad(double zaklad, double dph, double sazba, double celkem)
    {
        
    }
    
    private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    private static final int RANDOM_STRING_LENGTH = 10;

    public String generateRandomString() 
    {
       StringBuilder randStr = new StringBuilder();
        for(int i=0; i<RANDOM_STRING_LENGTH; i++){
            int number = getNazevDokladu();
            char ch = CHAR_LIST.charAt(number);
            randStr.append(ch);
        }
        return randStr.toString();
    }
    
    public int getNazevDokladu()
    {
        int randomInt = 0;
        Random randomGenerator = new Random();
        randomInt = randomGenerator.nextInt(CHAR_LIST.length());
        if (randomInt - 1 == -1) {
            return randomInt;
        } else {
            return randomInt - 1;
        }
    }

    public void setZaklad(double zakladSazby) {
        zakladSazby = (zakladSazby > 0.0) ? zakladSazby : 0.0;
    }

    public double getZaklad() throws IOException
    {
        try
        {
           System.out.print("Zadejte základní cenu: ");
           return (double) System.in.read();
        }
        catch (IOException ex)
        {
            throw ex;
        }
    }
}
