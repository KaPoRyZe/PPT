/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cv01;

/**
 *
 * @author zeman12
 */
public class Doklad {
    int zaklad; //pro výpocet dane
    double dph; //spoctena hodnota dane
    int celkem; //celkova hodnota
    double pdph = 0.21; //velikost dane
    String nazevDokladu = "";

    public void setNazevDokladu(String nazevDokladu) {
        this.nazevDokladu = (nazevDokladu != "") ? nazevDokladu : "chyba dokladu";

    }

    public String getNazevDokladu() {
        return this.nazevDokladu;
    }

    public void setZaklad(double zakladSazby) {
        zakladSazby = (zakladSazby > 0) ? zakladSazby : 0.0;
    }

    public double getZaklad() {
        return this.zaklad;
    }
}
