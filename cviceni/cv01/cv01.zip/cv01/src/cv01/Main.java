/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cv01;

import java.io.IOException;

/**
 *
 * @author zeman12
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double celkem;
        double zaklad;
        Doklad d = new Doklad();
        
        try
        {
            zaklad = d.getZaklad();
            System.out.println(zaklad);
        }
        catch (IOException ex)
        {
            System.out.println("Pri nacteni cisla doslo k chybe");
        }
        
       
    }
    
}
