﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using UcetniDoklady.Data;

namespace UcetniDoklady
{
    public partial class MainForm : Form
    {
        List<Doklad> lDoklady = new List<Doklad>();
        List<ZauctovaniDokladu> lDokladyZauctovane = new List<ZauctovaniDokladu>();


        public MainForm()
        {
            InitializeComponent();
        }

        private void btZauctuj_Click(object sender, EventArgs e)
        {
            ZauctovaniDokladu zauct = new ZauctovaniDokladu("MM", DateTime.Now, (Doklad)lbxDoklady.SelectedItem);
            try
            {
                zauct.Zauctuj();

                lDokladyZauctovane.Add(zauct);
                _obnovListBoxZauctovanychDokladu();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbxDoklady.DataSource = null;
            lbxDoklady.DataSource = lDoklady;

            _obnovListBoxZauctovanychDokladu();
        }

        private void _obnovListBoxZauctovanychDokladu()
        {
            lbxZauctovaneDoklady.DataSource = null;
            lbxZauctovaneDoklady.DataSource = lDokladyZauctovane;
        }

        private void btReport_Click(object sender, EventArgs e)
        {
            var reportPdf = new StringBuilder();
            var vybranyDoklad = (Doklad) lbxDoklady.SelectedItem;

            _ulozSouhrnneInformaceDokladuDoVykazu(vybranyDoklad, ref reportPdf); 
        }

        private void btReportAllSelected_Click(object sender, EventArgs e)
        {
            var reportPdf = new StringBuilder();

            foreach (Doklad doklad in lbxDoklady.SelectedItems)
            {
                _ulozSouhrnneInformaceDokladuDoVykazu(doklad, ref reportPdf);
                reportPdf.AppendLine("\n");
            }
        }

        private void _ulozSouhrnneInformaceDokladuDoVykazu(Doklad data, ref StringBuilder reportPdf)
        {
            try
            {
                reportPdf.Append(data.CisloDokladu);
                reportPdf.Append(";");

                if (chcbShowDatum.Checked)
                {
                    reportPdf.Append(data.Datum_Vystaveni);
                    reportPdf.Append(";");
                    reportPdf.Append(data.Datum_Splanosti);
                    reportPdf.Append(";");
                }

                reportPdf.Append(data.CenaSDPH);
                reportPdf.Append(";");

                if (!chcbShowDPH.Checked)
                {
                    return;
                }

                reportPdf.Append(data.SazbaDPH);
                reportPdf.Append(";");
            }
            catch (NullReferenceException)
            {
                MessageBox.Show(@"Nepovedlo se vygenerovat výkaz. Neexistující doklad.");
            }
            
        }
    }
}
