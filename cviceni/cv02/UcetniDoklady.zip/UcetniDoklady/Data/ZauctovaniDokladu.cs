﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UcetniDoklady.Data
{
    class ZauctovaniDokladu
    {
        public string Zauctoval { get; set; }
        public DateTime Datum_Zauctovani { get; set; }
        public Doklad DokladZauct { get; set; }
        public bool Zauct { get; set; }

        public ZauctovaniDokladu(string zauctoval, DateTime datumZauctovani, Doklad dokladZauct)
        {
            Zauctoval = zauctoval;
            Datum_Zauctovani = datumZauctovani;
            DokladZauct = dokladZauct;
            Zauct = false;
        }

        public decimal Zauctuj()
        {
            ProvedValidaci();

            if (DokladZauct.SazbaDPH <= 0)
            {
                DokladZauct.Zaokr = new decimal(0.0);
                return DokladZauct.CenaSDPH;
            }

            var decTmp = DokladZauct.CenaSDPH;
            if (DokladZauct.Datum_Vystaveni.Year <= 2010)
            {
                DokladZauct.CenaSDPH = decimal.Round(DokladZauct.CenaSDPH, 0);
                DokladZauct.Zaokr = decTmp - DokladZauct.CenaSDPH;
                return DokladZauct.CenaSDPH;
            }

            DokladZauct.CenaSDPH = decimal.Ceiling(DokladZauct.CenaSDPH);
            DokladZauct.Zaokr = decTmp - DokladZauct.CenaSDPH;
            return DokladZauct.CenaSDPH;
        }

        private void ProvedValidaci()
        {
            if (DokladZauct.Datum_Splanosti <= DokladZauct.Datum_Vystaveni)
            {
                throw new Exception(Properties.Resources.IDSE_ERROR_DT);
            }

            if (!DokladZauct.Calc)
            {
                throw new Exception(Properties.Resources.IDSE_ERROR_NOT_CALC);
            }
        }

    }
}
